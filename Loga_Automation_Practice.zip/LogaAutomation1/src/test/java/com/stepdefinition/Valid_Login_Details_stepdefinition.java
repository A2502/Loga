package com.stepdefinition;

import java.io.IOException;

import com.excelutility.Excel;
import com.page.Valid_Login_Details_Page;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Valid_Login_Details_stepdefinition extends Valid_Login_Details_Page  {
	
	 
	@Given("^Open the URL in the browser$")
	public void open_the_URL_in_the_browser()  {
	   
	Launch("http://automationpractice.com/index.php");
	// Opening the Loga Automation Practice website by entering url 
	}
	@When("^click signin$")
	public void click_signin()  {
	  
	 Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
	 // Inspected signin button by its xpath and clicking signin
	}

	@When("^Enter valid Usernameandpassword$")
	public void enter_valid_Usernameandpassword() throws IOException  {
	 
	for(int i=1;i<=2;i++)
	{
		usernameandpassword(i);
		Click("//*[@id=\"SubmitLogin\"]/span"); 
		if(i<=2)
		{
			Launch("http://automationpractice.com/index.php");
			Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
   // user name and password read through the data given in the excel sheet and following is the code
		}
	}
	
	}
	

	@Then("^Click on signin$")
	public void click_on_Signin()  {
	    
	  Click("//*[@id=\"SubmitLogin\"]/span");  
	  // Inspected signin button by its xpath and clicked on Signin
	}

}