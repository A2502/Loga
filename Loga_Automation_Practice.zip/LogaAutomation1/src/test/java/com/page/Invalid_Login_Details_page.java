package com.page;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import com.excelutility.Excel_1;

public class Invalid_Login_Details_page {
	WebDriver driver;
	public void Launch(String URL)  
	//method for launching the chrome browser
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		driver.get(URL);
	}
	public void Signin(String xpath) 
	// method for signin of the Loga Automation Practice website
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void usernameandpassword(int j) throws IOException  
	// method for reading username and password through excel sheet
	{
		Excel_1 e=new Excel_1();
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(e.excel_username(j));
		WebElement d = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		d.click();
		driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(e.excel_password(j));
		WebElement f = driver.findElement(By.xpath("//*[@id=\"passwd\"]"));
		f.click();
	
	}
	public void Click(String xpath) // method for clicking signin after entering valid username and password
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	
}
