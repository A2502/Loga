package com.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Valid_Registration_details_page {
	WebDriver driver;
	public void Launching(String browser,String URL)
	//method for launching the chrome browser
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		driver.get(URL);
	}
	public void Entering(String xpath,String values) 
	// method for entering registration details such as first name, last name, address, mobile number etc..
	{
		driver.findElement(By.xpath(xpath)).sendKeys(values);
	}
	public void clicking(String xpath)
	// method for clicking create an account after entering all the details
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	}

