package com.testrunner;

import org.junit.runner.RunWith;


import cucumber.api.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/main/resources/feature/Loga.feature",
		tags="@TC_02",
		glue="com.definition",
		monochrome=true
		)

public class Invalid_Registration_Details_testrunner {

}
